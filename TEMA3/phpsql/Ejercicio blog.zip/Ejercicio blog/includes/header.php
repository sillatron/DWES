<!DOCTYPE html>
<html>
    <?php if (!isset($_SESSION)) session_start(); ?>
    <head>
        <meta charset="UTF-8">
        <title>Blog</title>
        <link rel="stylesheet" type="text/css" href="../css/index.css">
    </head>
    <body>
        <header>
            <h1>Blog de videojuegos</h1>
        </header>
    </body>
</html>

