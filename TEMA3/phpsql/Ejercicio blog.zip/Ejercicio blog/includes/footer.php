<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Blog</title>
        <link rel="stylesheet" type="text/css" href="CSS/estilos.css">
    </head>
    <body>
        <footer><p>2019-Blog de videojuegos</p></footer>
    </body>
</html>


