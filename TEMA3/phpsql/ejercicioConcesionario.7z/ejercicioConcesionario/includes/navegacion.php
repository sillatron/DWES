<nav>
    <ul>
        <li><a href="index.php">Inicio</a></li>
        <li><a  href="alta.php">Insertar coche</a></li>
        <li><a href="listado_clientes.php">listado de clientes</a></li>
        <li><a  href="salir.php">Cerrar sesion</a></li>
        
    </ul>
</nav>