<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Concesionario</title>
        <link rel="stylesheet" type="text/css" href="CSS/estilos.css">
    </head>
    <body>
        <footer><p>Este es el footer</p></footer>
    </body>
</html>
